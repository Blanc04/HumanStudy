with open('order.txt', 'r', encoding='utf-8') as file:
    total = 0
    for order in file:
        items = order.split(',')
        product = items[0].strip()
        count = items[1].strip()
        price = items[2].strip()
        price = price.replace('원', '')
        count = int(count)
        price = int(price)
        if price >= 0 and price <= 10000 and count >= 0:
            total += count * price
            # print(product, count, price)
    print('전체 매출:', total)