package var_02;

import java.util.ArrayList;
import java.util.List;

public class List_08 {

	public static void main(String[] args) {
		// ����
		ArrayList list = new ArrayList();
		
		// �߰�
		list.add(1);
		list.add("�۾�");
		list.add(true);
		
		// ������
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		
		// ũ��
		System.out.println(list.size());
		
		// �ݺ������� list�� ��� ������ ���	
		for(int i=0; i<list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		for(Object obj : list) {
			System.out.println(obj);
		}
		
		int a = (int)list.get(0);
		
		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("����");
//		list2.add(1);
		
		String b = (String)list.get(1);
		String c = list2.get(0);
		
		List list3 = new ArrayList();
	}

}
